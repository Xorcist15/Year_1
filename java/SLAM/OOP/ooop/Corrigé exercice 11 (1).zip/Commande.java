/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exercice12;

import java.util.ArrayList;

/**
 *
 * @author mroess
 */
public class Commande {
	//Attributs privés
    private String reference;
    private String date;
    private float montant;
    private Client leClient;
    private ArrayList<LigneCommande> lesLignes;
    
	//Constructeur
    public Commande(String re, String da,Client cl){
        this.reference = re;
        this.date =da;
        this.montant = 0;
        this.leClient = cl;
        this.lesLignes = new ArrayList<LigneCommande>();
    }
    
    
    public void ajouterLigne(LigneCommande uneLigne){
		//Je cumule le montant de la ligne au montant de la commande
        this.montant = this.montant + uneLigne.montantLigne();
		//Je cumule le montant de la ligne au CA du client
        this.leClient.cumulerCa(uneLigne.montantLigne());
		//J'ajoute la ligne à la collection
        this.lesLignes.add(uneLigne);
    }
     
    public String toString(){
        String res; 
        res = "-----------------------------------";
        res += "\n\t\tCommande : ";
        res += "\n-----------------------------------";
        res += "\n\tRéférence : " + this.reference;
        res += "\n\tDate : " + this.date;
        res += "\n-----------------------------------";
        res += "\n\tRéférence Client : " + this.leClient.getReference();
        res += "\n\t Nom : " + this.leClient.getNom() + "\n";
        res += "\n-----------------------------------";
         for(LigneCommande uneLigne : this.lesLignes){
            res += "\n"  + uneLigne.toString();
        }
        res += "\n-----------------------------------";
        res += "\n\tTotal : " + this.montant;
        res += "\n-----------------------------------";
        res += "\nNouveau chiffre daffaire : " + this.leClient.getChiffreAffaire();
        res += "\n-----------------------------------";
        
        return res;
        
    }
    
	//Accesseur
    public String getReference(){
        return this.reference;
    
    }
    
     public String getdate(){
        return this.date;
    
    }
     
    public Client getLeclient(){
        return this.leClient;
    
    }
    
     public float getMontant(){
        return this.montant;
    }

}
