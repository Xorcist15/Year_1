/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercice12;

/**
 *
 * @author mroess
 */
public class Exercice12 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
		//Déclaration des variables objet
		Client client1;
		Article article1;
		LigneCommande ligneCommande1;
		Commande commande1;
       
	   //Je crée un client
	   client1 = new Client("A38 ","Roess"," Colmar ");
	   
	   //Je crée 2 articles
	   article1 = new Article("V1","VTT",200,300,1);
	   article2 = new Article("V2","VTC",150,200,1);	   
	   
	   //Je crée une commande
	   commande1 = new Commande("1234","12/02/2020",client1);
	   
	   //Je crée 2 lignes de commande
	   ligneCommande1 = new LigneCommande(10,article1);
	   ligneCommande2 = new LigneCommande(5,article2);	   
	   
		//Que j'ajoute à ma commande
	   commande1.ajouterLigne(ligneCommande1);		
	   commande1.ajouterLigne(ligneCommande2);       
	   
	   //J'affiche ma commande
	   System.out.print(commande1.toString());
    }
    
}
