/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exercice12;

/**
 *
 * @author mroess
 */
public class Article {
	//Attributs privés
    private String ref;
    private String libelle;
    private float prixAchat;
    private float prixVente;
    private int stock;
    
	//Constructeur
    public Article(String r,String l, float pa,float pv, int s){
        this.libelle = l;
        this.prixAchat = pa;
        this.prixVente = pv;
        this.ref = r;
        this.stock = s;
    }
    
	//Méthodes publiques
    public float valeurStock(){
        return (this.prixVente * this.stock);
    }
    
	//Accesseurs
    public String getLibelle(){
        return this.libelle;
    }
    public String getReference(){
        return this.ref;
    }
    public float getprixVente(){
        return this.prixVente;
    }
}
