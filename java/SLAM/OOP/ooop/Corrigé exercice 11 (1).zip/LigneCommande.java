/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exercice12;

/**
 *
 * @author mroess
 */
public class LigneCommande {
	//Attributs privés
    private int quantite;
    private Article unArticle;
    
	//Constructeur
    public LigneCommande(int q,Article a){
        this.quantite = q;
        this.unArticle = a;
    }
    
	//Méthodes publiques
    public String toString(){
        String res;
        res = this.unArticle.getReference();
        res = res + " " + this.unArticle.getLibelle();
        res =res + " " + this.unArticle.getprixVente();
        res = res + " X ";
        res = res + " " + this.quantite;
        res = res + " " + this.quantite * this.unArticle.getprixVente();
        return res;
    
    }
    
    public float montantLigne(){
        float res = (this.quantite * this.unArticle.getprixVente());
        return res;
    }
}

 