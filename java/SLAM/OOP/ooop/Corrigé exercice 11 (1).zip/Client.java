/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exercice12;

/**
 *
 * @author mroess
 */
public class Client {
    //Atributs privés
    private String reference;
    private String nom;
    private String ville;
    private float chiffreAffaires;
    
    //Constructeur
    public Client(String r ){
        this.reference = r;
        this.nom = "Anonyme";
        this.ville = "Inconnue";
        this.chiffreAffaires = 0;
    }
    public Client(String r,String n, String v ){
        this.reference = r;
        this.nom = n;
        this.ville = v;
        this.chiffreAffaires = 0;
    }
    
    //Ascesseur
    public String getReference(){
        return this.reference;
    }
    public String getNom(){
        return this.nom;
    }
    public String getVille(){
        return this.ville;
    }
    public void setVille(String v){
        this.ville = v;
    }
    public float getChiffreAffaire(){
        return this.chiffreAffaires;
    }
    public void setNom(String n){
        this.nom = n;
    }
    //Méthode toString
    public String toString(){
        return "Référence : " + this.reference + " Nom : " + this.nom + " Ville : " + this.ville + " Chiffre d'affaires : " + this.chiffreAffaires;
    }
    
    //Méthode cumulerCa
    public void cumulerCa(float cumul){
        this.chiffreAffaires = this.chiffreAffaires + cumul;
    }
}
